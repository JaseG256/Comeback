package com.msa.converse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConverseApplication.class, args);
	}

}
